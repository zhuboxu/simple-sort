#define _CRT_SECURE_NO_WARNINGS
#include "seqlist.h"

//初始化
void SL_Init(SL* seqlist)
{
	seqlist->arr = NULL;
	seqlist->num = 0;
	seqlist->size = 0;
}

//销毁
void SL_destroy(SL* seqlist)
{
	free(seqlist->arr);
}

//打印
//void SL_print(SL* seqlist)
//{
//	assert(seqlist);
//	for (int i = 0; i < seqlist->num; ++i)
//	{
//		printf("%d ", seqlist->arr[i]);//以整形为例
//	}
//	printf("\nnum = %d\n", seqlist->num);
//	printf("size = %d\n", seqlist->size);
//}

//空间检查
void SL_check_size(SL* seqlist)
{
	if (!(seqlist->arr))
	{
		seqlist->arr = malloc(4 * sizeof(sltype));
		seqlist->size = 4;
	}
	if (seqlist->num == seqlist->size)
	{
		sltype* tmp = (sltype*)realloc(seqlist->arr, sizeof(sltype) * 2 * seqlist->size);
		assert(tmp);
		tmp = seqlist->arr;
		tmp = NULL;
		seqlist->size *= 2;
	}
}


//尾插
void SL_push_back(SL* seqlist, sltype x)
{
	assert(seqlist);
	SL_check_size(seqlist);
	seqlist->arr[seqlist->num] = x;
	seqlist->num++;
}

//头插
void SL_push_front(SL* seqlist, sltype x)
{
	assert(seqlist);
	for (int i = seqlist->num; i > 0; --i)
	{
		seqlist->arr[i] = seqlist->arr[i - 1];
	}
	seqlist->arr[0] = x;
	seqlist->num++;
}

//尾删
void SL_pop_back(SL* seqlist)
{
	assert(seqlist);
	assert(seqlist->num);
	seqlist->num--;
}

//头删
void SL_pop_front(SL* seqlist)
{
	assert(seqlist);
	assert(seqlist->num);
	for (int i = 0; i < seqlist->num; ++i)
	{
		seqlist->arr[i] = seqlist->arr[i + 1];
	}
	seqlist->num--;
}

//指定位置插入数据
void SL_insert(SL* seqlist, int pos, sltype x)
{
	assert(seqlist);
	assert(pos >= 0 && pos <= seqlist->num);
	SL_check_size(seqlist);
	for (int i = seqlist->num; i > pos; --i)
	{
		seqlist->arr[i] = seqlist->arr[i - 1];
	}
	seqlist->arr[pos] = x;
	seqlist->num++;
}

//指定位置删除数据
void SL_erase(SL* seqlist, int pos)
{
	assert(seqlist);
	assert(pos >= 0 && pos < seqlist -> num);
	for (int i = pos; i < seqlist -> num - 1; ++i)
	{
		seqlist -> arr[i] = seqlist -> arr[i + 1];
	}
	seqlist->num--;
}

bool Cmp(sltype x, sltype y)
{
	if (strcmp(x.useer, y.useer) == 0 && strcmp(x.password, y.password) == 0)
	{
		return true;
	}
	return false;
}

//查找指定数据的位置
int SL_find(SL* seqlist, sltype x)
{
	assert(seqlist);
	for (int i = 0; i < seqlist->num; ++i)
	{
		if (Cmp(seqlist->arr[i], x))
		{
			return i;
		}
	}
	return EOF;
}//找到返回位置的下标，没找到返回EOF（-1）