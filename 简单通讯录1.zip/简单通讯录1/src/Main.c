#define _CRT_SECURE_NO_WARNINGS
#include"Single_linked_list.h"
#include"Contact.h"
#include"Register.h"
#include"seqlist.h"
#include<Windows.h>

//int main()
//{
//	SLT* head = NULL;
//	SLT* find = NULL;
//测试头插
/*SLT_push_front(&head, 1);
SLTPrint(head);
SLT_push_front(&head, 2);
SLTPrint(head);
SLT_push_front(&head, 3);
SLTPrint(head);
SLT_push_front(&head, 4);
SLTPrint(head);
SLT_push_front(&head, 5);
SLTPrint(head);
SLT_push_front(&head, 6);
SLTPrint(head);*/

//测试尾插
/*SLT_push_back(&head, 1);
SLTPrint(head);
SLT_push_back(&head, 2);
SLTPrint(head);
SLT_push_back(&head, 3);
SLTPrint(head);
SLT_push_back(&head, 4);
SLTPrint(head);
SLT_push_back(&head, 5);
SLTPrint(head);*/

//测试头删
/*SLT_push_back(&head, 1);
SLT_push_back(&head, 2);
SLT_push_back(&head, 3);
SLT_push_back(&head, 4);
SLT_push_back(&head, 5);
SLT_pop_front(&head);
SLTPrint(head);
SLT_pop_front(&head);
SLTPrint(head);
SLT_pop_front(&head);
SLTPrint(head);
SLT_pop_front(&head);
SLTPrint(head);
SLT_pop_front(&head);
SLTPrint(head);*/

//测试尾删
/*SLT_push_back(&head, 1);
SLT_push_back(&head, 2);
SLT_push_back(&head, 3);
SLT_push_back(&head, 4);
SLT_push_back(&head, 5);
SLTPrint(head);
SLT_pop_back(&head);
SLTPrint(head);
SLT_pop_back(&head);
SLTPrint(head);
SLT_pop_back(&head);
SLTPrint(head);
SLT_pop_back(&head);
SLTPrint(head);
SLT_pop_back(&head);
SLTPrint(head);*/

//测试查找
/*SLT_push_back(&head, 1);
SLT_push_back(&head, 2);
SLT_push_back(&head, 3);
SLT_push_back(&head, 4);

SLTPrint(head);
find = SLT_find(head, 0);
if (find != NULL)
{
	printf("%d\n", find->data);
}
else
{
	printf("NULL\n");
}*/
//测试在指定位置之前插入数据
/*SLT_push_back(&head, 1);
SLT_push_back(&head, 2);
SLT_push_back(&head, 3);
SLT_push_back(&head, 4);
SLTPrint(head);
SLT_insert_frond(&head, SLT_find(head, 4), 5);
SLTPrint(head);*/

//测试在指定位置之后插入数据
/*SLT_push_back(&head, 1);
SLT_push_back(&head, 2);
SLT_push_back(&head, 3);
SLT_push_back(&head, 4);
SLTPrint(head);
SLT_insert_back(head, SLT_find(head, 4), 5);
SLTPrint(head);*/

//测试删除指定位置的结点
/*SLT_push_back(&head, 1);
SLT_push_back(&head, 2);
SLT_push_back(&head, 3);
SLT_push_back(&head, 4);
SLTPrint(head);
SLT_erase(&head, SLT_find(head, 1));
SLTPrint(head);*/

//删除指定位置之后的结点
/*SLT_push_back(&head, 1);
SLT_push_back(&head, 2);
SLT_push_back(&head, 3);
SLT_push_back(&head, 4);
SLTPrint(head);
SLT_erase_back(head, SLT_find(head, 1));
SLTPrint(head);*/

//销毁链表
/*SLT_push_back(&head, 1);
SLT_push_back(&head, 2);
SLT_push_back(&head, 3);
SLT_push_back(&head, 4);
SLTPrint(head);
SLT_destroy(&head);
SLTPrint(head);*/

/*return 0;
}*/



void menu1()
{
    printf("*****************************************\n");
    printf("**** 1.登录       2.修改密码         ****\n");
    printf("**** 3.注册       4.超级管理员登录   ****\n");
    printf("**** 5.销毁账户   0.退出             ****\n");
    printf("*****************************************\n");
}

void menu2()
{
    printf("*************************************\n");
    printf("**** 1.添加联系人  2. 删除联系人 ****\n");
    printf("**** 3.修改联系人  4. 查找联系人 ****\n");
    printf("**** 5.销毁通讯录  6. 展示通讯录 ****\n");
    printf("**** 7.保存通讯录  0. 退出       ****\n");
    printf("**** 输入对应操作的数字以进行操作****\n");
    printf("*************************************\n");
}

void welcome()
{
    printf("**************************************\n");
    printf("****  欢迎来到简单通讯录管理系统  ****\n");
    printf("****     本系统的具体功能如下     ****\n");
    printf("**************************************\n\n");
    Sleep(1000);
    menu2();
    printf("\n如需使用本系统，请先注册账号或登录\n");
    Sleep(1000);
}

int main()
{
    welcome();
    contact* p = NULL;
    User_table user;
    SL_Init(&user);
    account person = { 0 };
    if (fopen("users.txt", "r") == NULL)
    {

        fclose(fopen("users.txt", "w"));
    }
    Read_account(&user);
    int op = -1;
begin:
    do {
        menu1();
        scanf("%d", &op);
        system("cls");
        switch (op)
        {
        case 1:
            if (Register(&user,&person))
            {
                goto next;
            }
            break;
        case 2:
            Modification(&user);
            break;
        case 3:
            Create_account(&user);
            break;
        case 4:
            Super_manager(&user);
            break;
        case 5:
            Destroy_account(&user);
            break;
        default:
            if(op != 0)
                printf("输入错误，请重新输入\n");
            break;
        }
    } while (op);
    goto end;
next:
    Init_contact(&p);
    Read_File(p,person.useer);
    do {
        printf("请选择你的操作（输入对应操作的数字）\n");
        menu2();
        scanf("%d", &op);

        system("cls");
        switch (op)
        {
        case 1:
            Add_contact(p);
            printf("\n");
            break;
        case 2:
            Del_contact(p);
            printf("\n");
            break;
        case 3:
            Moidfy_contact(p);
            printf("\n");
            break;
        case 4:
            Find_person(p);
            printf("\n");
            break;
        case 5:
            Destory_contact(&p);
            Init_contact(&p);
            printf("\n");
            break;
        case 6:
            Show_contact(p);
            printf("\n");
            break;
        case 7:
            Save_contact(p,person.useer);
            printf("\n");
            break;
        default:
            if (op != 0)
            {
                printf("输入错误，请重新输入\n");
            }
            printf("\n");
            break;
        }
    } while (op != 0);
    printf("请确认已经保存了修改，如要保存，请输入1，仍要退出请输入0\n");
    scanf("%d", &op);
    do
    {
        switch (op)
        {
        case 1 :
            Save_contact(p,person.useer);
            op = 0;
            break;
        default:
            if(op != 0)
                printf("输入非法，请输入1或0\n");
            break;
        }
    } while (op != 0);
    goto begin;
end:
    printf("退出成功!\n");

    return 0;
}