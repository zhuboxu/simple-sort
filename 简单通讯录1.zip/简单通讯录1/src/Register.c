#define _CRT_SECURE_NO_WARNINGS 1
#include"Register.h"
#include"Single_linked_list.h"
#include"seqlist.h"
//保存账号
void Save_account(User_table* table)
{
	FILE* fp = fopen("users.txt", "w");
	for (int i = 0; i < table->num; ++i)
	{
		fprintf(fp,"%s %s\n", table->arr[i].useer, table->arr[i].password);
	}
	fclose(fp);
}

//读取账号
void Read_account(User_table* table)
{
	FILE* fp = fopen("users.txt", "r");
	account person = { 0 };
	while (fscanf(fp, "%s %s\n", person.useer, person.password) != EOF)
	{
		SL_push_back(table, person);
	}
	fclose(fp);
}

//创建用户
void Create_account(User_table* table)
{
	account person = { 0 };
	char tmp[10000] = { 0 };
	while (1)
	{
		int f = 0;
		printf("请输入一个20位以内的用户名（如要退出注册请输入0）\n");
		scanf("%s", tmp);
		if (strlen(tmp) > 20)
		{
			printf("输入的用户名过长，请重新输入！\n");
			continue;
		}
		else
		{
			strcpy(person.useer, tmp);
		}
		if (strcmp(person.useer, "0") == 0)
		{
			printf("取消注册");
			return;
		}
		for (int i = 0; i < table->num; ++i)
		{
			if (strcmp(table->arr[i].useer, person.useer) == 0)
			{
				printf("该用户名已被占用，请重新输入\n");
				f = 1;
				break;
			}
		}
		if(f == 0)
		break;
	}
	while (1)
	{
		printf("请输入一个20位以内的密码（输入0取消注册）\n");
		scanf("%s", tmp);
		if (strlen(tmp) > 20)
		{
			printf("输入的密码过长，请重新输入！\n");
			continue;
		}
		else
		{
			strcpy(person.password, tmp);
		}
		if (strcmp(person.password, "0") == 0)
		{
			printf("取消注册");
			return;
		}
		break;
	}
	
	SL_push_back(table, person);
	Save_account(table);
	printf("您的用户名为：%s\n", person.useer);
	printf("您的密码为：%s\n", person.password);
	printf("创建账户成功！请妥善保管您的用户名和密码\n");
}

//判断是否存在该用户
bool Is_exist(User_table* table,account person)
{
	if (SL_find(table, person) != -1)
	{
		return true;
	}
	return false;
}

//登录
bool Register(User_table* table, account* ret)
{
		int f = 1;
		account person = { 0 };
		char tmp[1000] = { 0 };
		while (f)
		{
			f = 0;
			printf("请输入您的用户名\n");
			scanf("%s", tmp);
			if (strlen(tmp) > 20)
			{
				printf("输入的用户名过长，请重新输入！\n");
				f = 1;
			}
		}
		strcpy(person.useer, tmp);
		f = 1;
		while (f)
		{
			f = 0;
			printf("请输入您的密码\n");
			scanf("%s", tmp);
			if (strlen(tmp) > 20)
			{
				printf("输入的密码过长，请重新输入！\n");
				f = 1;
			}
		}
		strcpy(person.password, tmp);
		if (Is_exist(table, person))
		{
			*ret = person;
			return true;
		}
		printf("用户名或者密码输入错误，请重新输入\n");
		return false;
}
//修改用户名或密码
void Modification(User_table* table)
{
	char tmp[1000] = { 0 };
	account person = {0};
	int pos = -1;
	again2:
	printf("请输入修改前的用户名：\n");
	//scanf("%s", person.useer);
	scanf("%s", tmp);
	if (strlen(tmp) > 20)
	{
		printf("输入的用户名过长，请重新输入！\n");
		goto again2;
	}
	strcpy(person.useer, tmp);
	again3:
	printf("请输入修改前的密码： \n");
	//scanf("%s", person.password);
	scanf("%s", tmp);
	if (strlen(tmp) > 20)
	{
		printf("输入的密码过长，请重新输入！\n");
		goto again3;
	}
	strcpy(person.password, tmp);
	if ((pos = SL_find(table, person)) != -1)
	{
		char tmp[1000] = { 0 };
		int op = -1;
		do {
			printf("请选择要执行的操作\n");
			printf("1.修改密码    0.退出修改\n");
			scanf("%d", &op);
			switch (op)
			{
			case 1:
				printf("请输入新的密码（20个字符以内）\n");
				scanf("%s", tmp);
				if (strlen(tmp) > 20)
				{
					printf("输入的密码过长，请重新输入！\n");
					continue;
				}
				strcpy(table->arr[pos].password, tmp);
				printf("修改成功！\n");
				break;
			default:
				if(op != 0)
				printf("输入非法，请重新输入\n");
				break;
			}
		} while (op);
		Save_account(table);
		//printf("修改成功！\n");
		return;
	}
	else
	{
		printf("该账号不存在，修改失败！\n");
	}
}

//注销账户
void Destroy_account(User_table* table)
{
	char tmp[1000] = { 0 };
	account person = { 0 };
	int pos = -1;
	again4:
	printf("请输入您要注销的账户的用户名：\n");
	//scanf("%s", person.useer);
	scanf("%s", tmp);
	if (strlen(tmp) > 20)
	{
		printf("输入的用户名过长，请重新输入！\n");
		goto again4;
	}
	strcpy(person.useer, tmp);
	again5:
	printf("请输入您要注销的账户的密码：\n");
	//scanf("%s", person.password);
	scanf("%s", tmp);
	if (strlen(tmp) > 20)
	{
		printf("输入的密码过长，请重新输入！\n");
		goto again5;
	}
	strcpy(person.password, tmp);
	if ((pos = SL_find(table, person)) != -1)
	{
		int op = 0;
		printf("请确认是否注销该账户：\n");
		printf("输入1确认，输入0取消\n");
		do
		{
			scanf("%d", &op);
			switch (op)
			{
			case 1:
				SL_erase(table, pos);
				//remove(person.useer);
				FILE* fp = fopen(person.useer, "w");
				fclose(fp);
				Save_account(table);
				printf("注销成功！\n");
				return;
				break;
			default:
				if (op != 0)
					printf("输入非法，请重新输入1或0\n");
				break;
			}
		} while (op);
	}
	else
	{
		printf("查无此用户，注销失败！\n");
	}

}
///////////////////////////////////////////////////////////////////////////////////////////


void menu3()
{
	printf("***********************************************\n");
	printf("**** 1.查看用户列表   2.修改指定用户的密码 ****\n");
	printf("**** 3.添加用户       4.注销指定用户       ****\n");
	printf("**** 5.查找指定用户   0.退出登录           ****\n");
	printf("***********************************************\n");
}

//展示用户列表
void Show_account(User_table* table)
{
	printf("账号                   密码     \n");
	for (int i = 0; i < table->num; ++i)
	{
		printf("%-20s   %-20s\n", table->arr[i].useer,table->arr[i].password);
	}
}

//修改指定用户的密码
void Change_password(User_table* table)
{
	account person = { 0 };
	printf("请输入要修改账号的用户名\n");
	scanf("%s", person.useer);
	for (int i = 0; i < table->num; ++i)
	{
		if (strcmp(person.useer, table->arr[i].useer) == 0)
		{
			printf("原密码为：%s\n", table->arr[i].password);
			printf("请输入新的密码：");
			scanf("%s", person.password);
			table->arr[i] = person;
			Save_account(table);
			printf("修改成功！\n");
			return;
		}
	}
	printf("未查找到该用户，修改失败！\n");

}

//添加用户(复用前面的注册用户)

//注销指定用户
void Super_Destroy_account(User_table* table)
{
	account person = { 0 };
	int pos = -1;
	printf("请输入您要注销的账户的用户名：\n");
	scanf("%s", person.useer);
	for (int i = 0; i < table->num; ++i)
	{
		if (strcmp(table->arr[i].useer, person.useer) == 0)
		{
			pos = i;
			break;
		}
	}
	if (pos != -1)
	{
		int op = 0;
		printf("请确认是否注销该账户：\n");
		printf("输入1确认，输入0取消\n");
		do
		{
			scanf("%d", &op);
			switch (op)
			{
			case 1:
				SL_erase(table, pos);
				remove(person.useer);
				Save_account(table);
				printf("注销成功！\n");
				return;
			default:
				if (op != 0)
					printf("输入非法，请重新输入1或0\n");
				break;
			}
		} while (op);
	}
	else
	{
		printf("查无此用户，注销失败！\n");
	}

}

//查找指定用户
void Find_account(User_table* table)
{
	int pos = -1;
	account person = { 0 };
	printf("请输入要查找的用户的用户名\n");
	scanf("%s", person.useer);
	for (int i = 0; i < table->num; ++i)
	{
		if (strcmp(table->arr[i].useer, person.useer) == 0)
		{
			pos = i;
			break;
		}
	}
	if (pos != -1)
	{
		printf("该用户的用户名为：%s\n", table->arr[pos].useer);
		printf("该用户的密码为：%s\n", table->arr[pos].password);
	}
	else
	{
		printf("查无此用户！\n");
	}
}

//超级管理员
void Super_manager(User_table* table)
{
	char str[1000] = { 0 };
	printf("请输入超级管理员的账号密钥：\n");
	scanf("%s", str);
	if (strcmp(str, "sanxiadaxue") == 0)
	{
		int op = -1;
		do
		{
			menu3();
			printf("请选择你要进行的操作\n");
			scanf("%d", &op);
			system("cls");
			switch (op)
			{
			case 1:
				Show_account(table);
				break;
			case 2:
				Change_password(table);
				break;
			case 3:
				Create_account(table);
				break;
			case 4:
				Super_Destroy_account(table);
				break;
			case 5:
				Find_account(table);
				break;
			default:
				if (op != 0)
					printf("输入非法，请重新输入\n");
				break;
			}

		} while (op);

	}
	else
	{
		printf("密钥输入错误\n");
	}
}