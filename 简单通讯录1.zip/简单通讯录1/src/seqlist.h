#pragma once
#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<stdbool.h>
#include<string.h>
#include"Contact.h"
#include"Register.h"
typedef struct account sltype;


typedef struct SL {
	sltype* arr;
	int num;
	int size;
}SL;

//初始化
void SL_Init(SL* seqlist);
//销毁
void SL_destroy(SL* seqlist);
//打印
void SL_print(SL* seqlist);
//空间检查
void SL_check_size(SL* seqlist);

//尾插
void SL_push_back(SL* seqlist, sltype x);
//头插
void SL_push_front(SL* seqlist, sltype x);
//尾删
void SL_pop_back(SL* seqlist);
//头删
void SL_pop_front(SL* seqlist);
//指定位置插入数据
void SL_insert(SL* seqlist, int pos, sltype x);
//指定位置删除数据
void SL_erase(SL* seqlist, int pos);
//查找指定数据的位置
int SL_find(SL* seqlist, sltype x);