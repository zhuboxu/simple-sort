#pragma once
#define NAME_MAX 21
#define GENDER_MAX 10
#define TEL_MAX 20
#define ADDR_MAX 101

typedef struct SLT_node contact;

typedef struct person
{
	char name[NAME_MAX];
	char gender[GENDER_MAX];
	int age;
	char tel[TEL_MAX];
	char addr[ADDR_MAX];
}person;

//初始化通讯录
void Init_contact(contact** ct);
//读取文档中之前存的通讯录
void Read_File(contact* ct, char* dest);
//展示通讯录
void Show_contact(contact* ct);
//添加通讯录
void Add_contact(contact* ct);
//查找通讯录
contact* Find_contact(contact* ct , char* name);
//删除通讯录
void Del_contact(contact* ct);
//修改通讯录
void Moidfy_contact(contact* ct);
//销毁通讯录
void Destory_contact(contact** ct);
//查找联系人
void Find_person(contact* ct);
contact* Find_contact_name(contact* ct, char* name);
int Find_persons_name(contact* ct);
void Find_persons_tel(contact* ct);
//查找通讯录（用电话号码查找）
contact* Find_contact_tel(contact* ct, char* tel);
//保存通讯录
void Save_contact(contact* ct, char* dest);
//打印联系人
void Print_Person(contact* ct);
