#define _CRT_SECURE_NO_WARNINGS

#include"Single_linked_list.h"


//打印链表
//void SLTPrint(SLT* phead)
//{
//	while (phead)//phead不为空
//	{
//		printf("%d->", phead->data);
//		phead = phead->next;
//	}
//	printf("NULL\n");
//}

//创建一个节点
SLT* SLT_create(SLT_data_type x)
{
	SLT* p = (SLT*)malloc(sizeof(SLT));
	p->data = x;
	p->next = NULL;
	assert(p);
	return p;
}

//头插
void SLT_push_front(SLT** pphead,SLT_data_type x)
{
	assert(pphead);
	SLT* p = SLT_create(x);
	if (*pphead == NULL)
	{
		*pphead = p;
	}
	else
	{
		p->next = *pphead;
		*pphead = p;
	}
}

//尾插
void SLT_push_back(SLT** pphead, SLT_data_type x)
{
	assert(pphead);
	SLT* p = SLT_create(x);
	if (*pphead == NULL)
	{
		*pphead = p;
	}
	else
	{
		SLT* tail = *pphead;
		while (tail->next != NULL)
		{
			tail = tail->next;
		}
		tail->next = p;
	}
}

//头删
void SLT_pop_front(SLT** pphead)
{
	assert(pphead && *pphead);
	SLT* p = *pphead;
	*pphead = (*pphead)->next;
	free(p);
}

//尾删
void SLT_pop_back(SLT** pphead)
{
	assert(pphead && *pphead);
	SLT* tail = (*pphead)->next;
	if (tail == NULL)//链表只有一个节点
	{
		free(*pphead);
		*pphead = NULL;
	}
	else//链表不只有一个节点
	{
		SLT* pri = *pphead;//tail的前一个节点
		while (tail->next != NULL)
		{
			tail = tail->next;
			pri = pri->next;
		}
		pri->next = NULL;
		free(tail);
	}
}

//查找
//SLT* SLT_find(SLT* phead,SLT_data_type x)
//{
//	assert(phead);
//	SLT* find = phead;
//	while (find != NULL)
//	{
//		if (find->data == x)
//		{
//			return find;
//		}
//		find = find->next;
//	}
//	return NULL;
//}

//在指定位置前插入数据
void SLT_insert_frond(SLT** pphead, SLT* pos, SLT_data_type x)
{
	assert(pphead && *pphead);
	assert(pos);
	
	if (*pphead == pos)//要在第一个节点之前插入数据
	{
		SLT_push_front(pphead, x);
	}
	else//其他结点
	{
		SLT* p = SLT_create(x);
		SLT* dest = (*pphead)->next;
		while (dest->next != NULL)
		{
			if (dest->next == pos)
			{
				p->next = dest->next;
				dest->next = p;
				return;
			}
			dest = dest->next;
		}
	}
}

//在指定位置之后插入数据
void SLT_insert_back(SLT* phead, SLT* pos, SLT_data_type x)
{
	assert(phead);
	assert(pos);
	SLT* p = SLT_create(x);
	SLT* dest = phead;
	while (dest != NULL)
	{
		if (dest == pos)
		{
			p->next = dest->next;
			dest->next = p;
			return;
		}
		dest = dest->next;
	}
}

//删除指定位置的结点
void SLT_erase(SLT** pphead, SLT* pos)
{
	assert(pphead && *pphead);
	assert(pos);
	if (pos == *pphead)
	{
		SLT_pop_front(pphead);
	}
	else
	{
		SLT* dest = (*pphead)->next;
		SLT* pri = *pphead;
		while (dest != NULL)
		{
			if (dest == pos)
			{
				pri->next = dest->next;
				free(dest);
				return;
			}
			pri = pri->next;
			dest = dest->next;
		}
	}
}

//删除指定位置之后的结点
void SLT_erase_back(SLT* phead, SLT* pos)
{
	SLT* dest = phead;
	SLT* pri = NULL;
	while (dest->next != NULL)
	{
		if (dest == pos)
		{
			pri = dest->next;
			dest->next = dest->next->next;
			free(pri);
			return;
		}
		dest = dest->next;
	}
}

//销毁链表
void SLT_destroy(SLT** pphead)
{
	assert(pphead && *pphead);
	SLT* pos = *pphead;
	SLT* del = *pphead;
	while (del != NULL)
	{
		pos = pos->next;
		free(del);
		del = pos;
	}
	*pphead = NULL;
}
