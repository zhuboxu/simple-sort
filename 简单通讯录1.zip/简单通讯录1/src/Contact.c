#define _CRT_SECURE_NO_WARNINGS
#include"Single_linked_list.h"
#include "Contact.h"
#include"Register.h"

//初始化通讯录
void Init_contact(contact** ct)
{
	person p = { 0 };
	*ct = SLT_create(p);
	(*ct)->next = NULL;
}

//读取文档中之前存的通讯录
void Read_File(contact* ct, char* dest)
{
	FILE* fcontact = fopen(dest , "r");
	if (fcontact == NULL)
	{
		return;
	}
	person add = { 0 };
	while (fscanf(fcontact, "%s %s %d %s %s\n",
		add.name,
		add.gender,
		&add.age,
		add.tel,
		add.addr) != EOF)
	{
		SLT_push_back(&ct, add);
	}
	
}

//展示通讯录
void Show_contact(contact* ct)
{
	assert(ct);
	contact* p = ct->next;
	printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
	while (p)
	{
		printf("%-20s %-8s %-8d %-20s %-8s\n",
			p->data.name,
			p->data.gender,
			p->data.age,
			p->data.tel,
			p->data.addr);
		p = p->next;
	}
}

//添加通讯录
//void Add_contact(contact* ct)
//{
//	assert(ct);
//	person add = { 0 };
//	printf("请输入要添加联系人的姓名\n");
//	scanf("%s", add.name);
//	printf("请输入要添加联系人的性别\n");
//	scanf("%s", add.gender);
//	printf("请输入要添加联系人的年龄\n");
//	scanf("%d", &add.age);
//	printf("请输入要添加联系人的电话\n");
//	scanf("%s", add.tel);
//	printf("请输入要添加联系人的地址\n");
//	scanf("%s", add.addr);
//	contact* p = ct;
//	while (p != NULL)
//	{
//		if (strcmp(add.name, p->next->data.name) < 0)
//		{
//			SLT_insert_frond(&ct, p->next, add);
//			return;
//		}
//		p = p->next;
//	}
//	SLT_push_back(&ct, add);
//}

//void Add_contact(contact* ct)//在指定位置之前插入
//{
//	assert(ct);
//	person add = { 0 };
//	int select = 2;
//	printf("请输入要添加联系人的姓名\n");
//	scanf("%s", add.name);
//	printf("请输入要添加联系人的性别\n");
//	scanf("%s", add.gender);
//	printf("请输入要添加联系人的年龄\n");
//	scanf("%d", &add.age);
//	printf("请输入要添加联系人的电话\n");
//	scanf("%s", add.tel);
//	printf("请输入要添加联系人的地址\n");
//	scanf("%s", add.addr);
//	contact* cur = ct;
//	contact* put = SLT_create(add);
//	do {
//		if (strcmp(put->data.name, cur->data.name) < 0) {
//			SLT_push_front(&ct, add);
//			break;
//		}
//		if (strcmp(put->data.name, cur->data.name) >= 0) {
//			if (cur->next == NULL) {
//				cur->next = put;
//				break;
//			}
//			if (strcmp(put->data.name, cur->next->data.name) <= 0) {
//				put->next = cur->next;
//				cur->next = put;
//				break;
//			}
//		}
//		cur = cur->next;
//	} while (cur);
//	//SLT_push_back(&ct, add);
//}

void Add_contact(contact* ct)//在指定位置之前插入
{
	assert(ct);
	char tmp[1000] = { 0 };
	person add = { 0 };
	again1:
	printf("请输入要添加联系人的姓名(20个字符以内)\n");
	printf("输入0退出\n");
	//scanf("%s", add.name);
	//while (getchar() != '\n');
	scanf("%s", tmp);
	if (strcmp(tmp, "0") == 0)
	{
		return;
	}
	if (strlen(tmp) > 20)
	{
		printf("输入的姓名过长，请重新输入！\n");
		goto again1;
	}
	strcpy(add.name, tmp);
	printf("请选择要添加联系人的性别(输入0选择'男'或输入1选择'女')\n");
	int put1 = -1;
	while (1) {
		if (scanf("%d", &put1) != EOF) {
			if (put1 == 0) {
				strcpy(add.gender, "男");
				break;
			}
			if (put1 == 1) {
				strcpy(add.gender, "女");
				break;
			}
		}
		while (getchar() != '\n');//如果是字符，清除后续
		printf("输入错误请重新输入\n(输入0选择'男'或输入1选择'女')\n");
	}
	printf("请输入要添加联系人的年龄(输入1-150岁)\n");

	while (1) {
		scanf("%d", &add.age);
		while (getchar() != '\n');//如果是字符，清除后续
		if (add.age > 0 && add.age <= 150) {
			break;
		}
		printf("输入错误，请重新输入(输入1-150岁)\n");
	}
	again6:
	printf("请输入要添加联系人的电话(请输入11位电话号码)\n");
	printf("输入0退出\n");
	while (1) {
		scanf("%s", add.tel);
		if (strcmp(add.tel, "0") == 0)
		{
			return;
		}
		if (strlen(add.tel) == 11) {
			contact* dest = NULL;
			if ((dest = Find_contact_tel(ct, add.tel)) == NULL) {
				break;
			}
			else
			{
				printf("输入电话号码与他人重复，请重新输入(请输入11位电话号码)\n");
			}

		}
		else
		{
			printf("输入格式错误，请重新输入(请输入11位电话号码)\n");
		}
	}
	
	contact* pp = ct;
	while (pp != NULL)
	{
		if (strcmp(pp->data.tel, add.tel) == 0)
		{
			printf("通讯录中已有相同的电话，请重新输入或退出\n");
			goto again6;
		}
		pp = pp->next;
	}


	printf("请输入要添加联系人的地址(100个字符以内)\n");
	printf("输入0退出\n");
	scanf("%s", add.addr);
	if (strcmp(add.addr, "0") == 0)
	{
		return;
	}
	while (getchar() != '\n');
	contact* cur = ct;
	contact* put = SLT_create(add);
	do {
		if (strcmp(put->data.name, cur->data.name) < 0) {
			SLT_push_front(&ct, add);
			break;
		}
		if (strcmp(put->data.name, cur->data.name) >= 0) {
			if (cur->next == NULL) {
				cur->next = put;
				break;
			}
			if (strcmp(put->data.name, cur->next->data.name) <= 0) {
				put->next = cur->next;
				cur->next = put;
				break;
			}
		}
		cur = cur->next;
	} while (cur);
	//SLT_push_back(&ct, add);
}



//查找通讯录
contact* Find_contact(contact* ct, char* name)
{
	assert(ct);
	contact* ret = ct->next;
	while (ret)
	{
		if (strcmp(ret->data.name, name) == 0)
		{
			return ret;
		}
		ret = ret->next;
	}
	return NULL;
}



//删除通讯录
//void Del_contact(contact* ct)
//{
//	assert(ct);
//	char name[NAME_MAX] = {0};
//	contact* dest = NULL;
//	printf("请输入要删除的联系人姓名\n");
//	scanf("%s", name);
//	dest = Find_contact(ct, name);
//	SLT_erase(&ct, dest);
//	printf("删除成功\n");
//}

// 删除通讯录联系人
void Del_contact(contact * ct)
{
	assert(ct);
	int op1 = -1;
	while (1) {
		printf("输入0用名字查找要删除的联系人，输入1用电话号码查找要删除的联系人,-1退出\n");
		scanf("%d", &op1);
		if (op1 == -1)
			return;
		if (op1 == 1) {
			printf("查找该电话的联系人\n");
			char tel[TEL_MAX];
			printf("请输入要查找的联系人电话(11位电话号码) 输入0退出\n");
			do {
				scanf("%s", tel);
				if (strlen(tel) == 11) {
					break;
				}
				if(strcmp(tel, "0") != 0)
				printf("输入错误，请重新输入联系人电话(11位电话号码)\n");
			} while (strcmp(tel,"0") != 0);
			if (strcmp(tel, "0") == 0)
			{
				return;
			}
			contact* dest = NULL;
			dest = Find_contact_tel(ct, tel);

			if (dest == NULL)
			{
				printf("无此联系人\n");
				return;
			}
			printf("该联系人的信息如下\n");
			printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
			Print_Person(dest);
			printf("请确认是否删除，输入1确认。输入0退出\n");
				int op = -1;
			do {
				scanf("%d", &op);
				if (op == 1)
				{
					SLT_erase(&ct, dest);
					printf("删除成功!");
					break;
				}
				else if(op != 0)
				{
					printf("输入错误，请输入1确认，0退出\n");
				}
			} while (op);
			
			break;
		}
		if (op1 == 0) {
			contact* dest = NULL;
			char name[NAME_MAX];
			printf("请输入该联系人的姓名\n");
			scanf("%s", name);
			dest = Find_contact_name(ct, name);
			if (dest == NULL)
			{
				printf("无此联系人，请重新输入\n");
				continue;
			}
			/*int flag = Find_persons_name(ct);
			if (flag == 1) {
				printf("只有一个联系人是这个名字\n");
				printf("输入1确认删除，输入0退出\n");
				char name[NAME_MAX];
				scanf("%s", name);
				dest = Find_contact_name(ct, name);
				if (dest == NULL)
					return;
				SLT_erase(&ct, dest);
				printf("删除成功\n");
				break;
			}*/

			while (dest != NULL)
			{
				printf("%-20s %-8s %-8s %-20s \t%-8s \n", "姓名", "性别", "年龄", "电话", "住址");
				Print_Person(dest);
				printf("请确认是否修改该联系人，输入1确定，输入2修改下一个联系人，输入0退出\n");
				int opp = -1;
				do
				{
					scanf("%d", &opp);
					if (opp == 1)
					{
						goto next3;
					}
					else if (opp == 0)
					{
						return;
					}
					else if (opp == 2)
					{
						break;
					}
					else
					{
						printf("输入错误，请输入1确认，输入2选择下一个，输入0退出\n");
					}

				} while (opp);
				dest = Find_contact(dest, name);
			}

			if (dest == NULL)
			{
				printf("已经是最后一个联系人了\n");
				continue;
			}


			/*if (flag > 1) {
				printf("查找到多个联系人,输入要删除的联系人的电话\n");
				char tel[TEL_MAX];
				while (1) {
					again7:
					scanf("%s", tel);
					if (strlen(tel) == 11)
						break;
					printf("输入错误，请重新输入11位电话\n");
				}
				dest = Find_contact_tel(ct, tel);
				if (dest == NULL)
				{
					printf("输入联系人的电话错误请重新输入\n");
					goto again7;
				}
				SLT_erase(&ct, dest);
				printf("删除成功!\n");
				break;
			}*/
		next3:
			printf("输入1确认删除，输入0退出\n");
			op1 = -1;
			do
			{
				scanf("%d", &op1);
				if (op1 == 1)
				{
					SLT_erase(&ct, dest);
					printf("删除成功！\n");
					return;
				}
				if (op1 != 0 && op1 != 1)
				{
					printf("输入错误，请重新输入\n");
				}
			} while (op1);
		}
		//printf("输入0用名字查找要修改的联系人，输入1用电话号码查找要修改的联系人,-1退出\n");

	}
}
//修改通讯录
//void Moidfy_contact(contact* ct)
//{
//	assert(ct);
//	char name[NAME_MAX] = {0};
//	contact* dest = NULL;
//	person new = { 0 };
//
//	printf("请输入要修改联系人的姓名\n");
//	scanf("%s", name);
//
//	dest = Find_contact(ct, name);
//
//	printf("%-8s %-8s %-8d %-8s %-8s \n",
//		dest->data.name,
//		dest->data.gender,
//		dest->data.age,
//		dest->data.tel,
//		dest->data.addr);
//
//	printf("请输入新联系人的姓名\n");
//	scanf("%s", new.name);
//	printf("请输入新联系人的性别\n");
//	scanf("%s", new.gender);
//	printf("请输入新联系人的年龄\n");
//	scanf("%d", &new.age);
//	printf("请输入新联系人的电话\n");
//	scanf("%s", new.tel);
//	printf("请输入新联系人的地址\n");
//	scanf("%s", new.addr);
//
//	dest->data = new;
//	printf("修改成功\n");
//
//}

void Moidfy_contact(contact* ct)
{
	int op = -1;
	char tmp[1000] = { 0 };
	assert(ct);
	char name[NAME_MAX] = { 0 };
	contact* dest = NULL;
	person new = { 0 };

	printf("请输入要修改联系人的姓名\n");
	scanf("%s", name);
	again8:
	dest = Find_contact(ct, name);
	if (dest == NULL)
	{
		printf("无此联系人，修改失败！\n");
		return;
	}
	int f = 0;
	
	while (dest != NULL)
	{
		printf("%-20s %-8s %-8s %-20s \t%-8s \n", "姓名", "性别", "年龄", "电话", "住址");
		Print_Person(dest);
		printf("请确认是否修改该联系人，输入1确定，输入2修改下一个联系人，输入0退出\n");
		int opp = -1;
		do
		{
			scanf("%d", &opp);
			if (opp == 1)
			{
				goto next2;
			}
			else if (opp == 0)
			{
				return;
			}
			else if(opp == 2)
			{
				break;
			}
			else
			{
				printf("输入错误，请输入1确认，输入2选择下一个，输入0退出\n");
			}
			
		} while (opp);
		dest = Find_contact(dest, name);
	}
	if (dest == NULL)
	{
		printf("已经是最后一个联系人了，输入1重新选择联系人，输入0退出\n");
		int opp = -1;
		do
		{
			scanf("%d", &opp);
			if (opp == 1)
			{
				goto again8;
			}
			if (opp == 0)
			{
				return;
			}
		} while (opp);
	}
	
next2:
	
	do {
		
		printf("----输入0：退出本次修改---\n");
		printf("----输入1：修改联系人的名字---\n");
		printf("----输入2：修改联系人的性别---\n");
		printf("----输入3：修改联系人的年龄---\n");
		printf("----输入4：修改联系人的电话---\n");
		printf("----输入5：修改联系人的住址---\n");
		printf("请选择你的操作\n");
		scanf("%d", &op);
		system("cls");
		switch (op)
		{
		case 0:break;
		case 1:printf("请输入新联系人的姓名，输入0退出\n");
			do
			{
				scanf("%s", tmp);
				if (strcmp(tmp, "0") == 0)
				{
					return;
				}
				else if (strlen(tmp) <= 20)
				{
					strcpy(dest->data.name, tmp);
					break;
				}
				else
				{
					printf("输入过长，请重新输入，输入0退出\n");
				}
			} while (1);
			printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
			Print_Person(dest);
			break;
		case 2:
			printf("请选择要修改联系人的性别(输入0选择'男'或输入1选择'女')\n");
			int put1 = -1;
			while (1) {
				if (scanf("%d", &put1) != EOF) {
					if (put1 == 0) {
						strcpy(dest->data.gender, "男");
						break;
					}
					if (put1 == 1) {
						strcpy(dest->data.gender, "女");
						break;
					}
				}
				while (getchar() != '\n');//如果是字符，清除后续
				printf("输入错误请重新输入\n(输入0选择'男'或输入1选择'女')\n");
			}
			printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
			Print_Person(dest);
			break;
		case 3:
			printf("请输入要修改联系人的年龄(输入1-150岁)\n");

			while (1) {
				scanf("%d", &(dest->data.age));
				while (getchar() != '\n');//如果是字符，清除后续
				if (dest->data.age > 0 && dest->data.age <= 150) {
					break;
				}
				printf("输入错误，请重新输入(输入1-150岁)\n");
			}
			printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
			Print_Person(dest);
			break;
		case 4:
			printf("请输入新联系人的电话，输入0退出\n");
			do
			{
				
				scanf("%s", tmp);
				if (strcmp(tmp, "0") == 0)
				{
					printf("退出成功！\n");
					return;
				}
				else if (strlen(tmp) == 11)
				{
					if (Find_contact_tel(ct, tmp) == NULL)
					{
						strcpy(dest->data.tel, tmp);
						break;
					}
					else
					{
						printf("该电话已经存在，请重新输入\n");
					}
				}
				else 
				{
					printf("输入错误，请重新输入11位号码，输入0退出\n");
				}

			} while (1);
			
			printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
			Print_Person(dest);
			break;
		case 5:printf("请输入新联系人的地址\n");
			scanf("%s", dest->data.addr);
			printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
			Print_Person(dest);
			break;
		default:
			printf("输入错误，请重新输入\n");
			break;
		}
	} while (op != 0);
	/*printf("请输入新联系人的姓名\n");
	scanf("%s", new.name);
	printf("请输入新联系人的性别\n");
	scanf("%s", new.gender);
	printf("请输入新联系人的年龄\n");
	scanf("%d", &new.age);
	printf("请输入新联系人的电话\n");
	scanf("%s", new.tel);
	printf("请输入新联系人的地址\n");
	scanf("%s", new.addr);*/
	printf("修改成功\n");
}

//销毁通讯录
void Destory_contact(contact** ct)
{
	assert(ct && *ct);
	int op = -1;
	printf("请输入1确认销毁，输入0取消销毁\n");
	do
	{
		scanf("%d", &op);
		switch (op)
		{
		case 1:
			SLT_destroy(ct);
			printf("销毁成功\n");
			return;
			break;
		default:
			if(op != 0)
			printf("输入非法，请输入1或0\n");
			break;
		}
	} while (op);
}

//查找联系人
//void Find_person(contact* ct)
//{
//	char name[NAME_MAX] = { 0 };
//	contact* dest = NULL;
//	printf("请输入要查找的联系人姓名\n");
//	scanf("%s", name);
//	dest = Find_contact(ct, name);
//	if (dest == NULL)
//	{
//		printf("无此联系人\n");
//		return;
//	}
//	printf("该联系人的信息如下\n");
//	printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
//	Print_Person(dest);
//	while (dest = Find_contact(dest, name))
//	{
//		Print_Person(dest);
//	}

//查找通讯录联系人(用电话号码)
contact* Find_contact_tel(contact* ct, char* tel)
{
	assert(ct);
	contact* ret = ct->next;
	while (ret)
	{
		if (strcmp(ret->data.tel, tel) == 0)
		{
			return ret;
		}
		ret = ret->next;
	}
	return NULL;
}
//查找联系人或有多人（用电话号码）
void Find_persons_tel(contact* ct)
{
	char tel[TEL_MAX];
	printf("请输入要查找的联系人电话(11位电话号码)\n");
	while (1) {
		scanf("%s", tel);
		if (strlen(tel) == 11) {
			break;
		}
		printf("输入错误，请重新输入联系人电话(11位电话号码)\n");
	}
	contact* dest = NULL;
	dest = Find_contact_tel(ct, tel);

	if (dest == NULL)
	{
		printf("无此联系人\n");
		return;
	}
	printf("该联系人的信息如下\n");
	printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
	Print_Person(dest);
	while (dest = Find_contact_tel(dest, tel))
	{
		Print_Person(dest);
	}
}

//void Find_persons_name(contact* ct)
//{
//	char name[NAME_MAX];
//	contact* dest = NULL;
//	printf("请输入要查找的联系人名字\n");
//	scanf("%s", name);
//	dest = Find_contact_name(ct, name);
//	if (dest == NULL)
//	{
//		printf("无此联系人\n");
//		return;
//	}
//	printf("该名字联系人的信息如下\n");
//	printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
//	Print_Person(dest);
//	while (dest = Find_contact_name(dest, name))
//	{
//		Print_Person(dest);
//	}

int Find_persons_name(contact* ct)
{
	int flag = 0;
	char name[NAME_MAX];
	contact* dest = NULL;
	printf("请输入要查找的联系人们的名字\n");
	scanf("%s", name);
	dest = Find_contact_name(ct, name);
	if (dest == NULL)
	{
		printf("无此联系人\n");
		return flag;
	}
	flag++;
	printf("该名字联系人的信息如下\n");
	printf("%-20s %-8s %-8s %-20s %-8s \n", "姓名", "性别", "年龄", "电话", "住址");
	Print_Person(dest);
	while (dest = Find_contact_name(dest, name))
	{
		flag++;
		Print_Person(dest);
	}


	/*if (flag == 1)
	{
		printf("请确认是否删除该联系人，输入1确认，输入0退出\n");
		int op = -1;
		do
		{
			scanf("%d", &op);
			if (op == 1)
			{
				SLT_erase(&ct, Find_contact_name(ct, name));
				return 1;
			}
			else if(op == 0)
			{
				printf("删除失败，退出！\n");
				return 1;
			}
			else
			{
				printf("输入错误，请输入1确认，0退出\n");
			}
		} while (op);
		
	}*/
	return flag;


	/*printf("%-8s %-8s %-8d %-8s %-8s \n",
		dest->data.name,
		dest->data.gender,
		dest->data.age,
		dest->data.tel,
		dest->data.addr);

	/*printf("%-8s %-8s %-8d %-8s %-8s \n",
		dest->data.name,
		dest->data.gender,
		dest->data.age,
		dest->data.tel,
		dest->data.addr);*/
}


/*printf("%-8s %-8s %-8d %-8s %-8s \n",
	dest->data.name,
	dest->data.gender,
	dest->data.age,
	dest->data.tel,
	dest->data.addr);*/


contact* Find_contact_name(contact* ct, char* name)
{
	assert(ct);
	contact* ret = ct->next;
	while (ret)
	{
		if (strcmp(ret->data.name, name) == 0)
		{
			return ret;
		}
		ret = ret->next;
	}
	return NULL;
}



void Find_person(contact* ct) {
	char op[100] = { 0 };
	system("cls");
	printf("输入0用名字查找联系人，输入1用电话号码查找联系人\n");
	while (1) {
		scanf("%s", op);
		//while (getchar());
		if (strcmp(op,"0") == 0) {
			Find_persons_name(ct);
			break;
		}
		if (strcmp(op, "1") == 0) {
			Find_persons_tel(ct);
			break;
		}
		printf("输入错误，输入0用名字查找联系人，输入1用电话号码查找联系人\n");
		continue;
	}
}



//保存通讯录
void Save_contact(contact* ct, char* dest)
{
	assert(ct);
	FILE* fcontact = fopen(dest, "w");
	contact* p = ct->next;
	while (p != NULL)
	{
		fprintf(fcontact, "%s ", p->data.name);
		fprintf(fcontact, "%s ", p->data.gender);
		fprintf(fcontact, "%d ", p->data.age);
		fprintf(fcontact, "%s ", p->data.tel);
		fprintf(fcontact, "%s ", p->data.addr);
		p = p->next;
	}
	printf("保存成功！\n");
	fclose(fcontact);
}

void Print_Person(contact* ct) {
	printf("%-20s %-8s %-8d %-20s %-8s \n",
		ct->data.name,
		ct->data.gender,
		ct->data.age,
		ct->data.tel,
		ct->data.addr);
}