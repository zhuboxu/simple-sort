#pragma once
#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
#include<string.h>
#include"Contact.h"
typedef struct person SLT_data_type;//链表的数据类型

typedef struct SLT_node//单个链表节点
{
	SLT_data_type data;
	struct SLT_node* next;
}SLT;//别名

//打印链表
void SLTPrint(SLT* phead);
//创建一个节点
SLT* SLT_create(SLT_data_type x);
//头插
void SLT_push_front(SLT** pphead,SLT_data_type x);
//尾插
void SLT_push_back(SLT** pphead, SLT_data_type x);
//头删
void SLT_pop_front(SLT** pphead);
//尾删
void SLT_pop_back(SLT** pphead);
//查找
SLT* SLT_find(SLT* phead,SLT_data_type x);
//在指定位置之前插入
void SLT_insert_frond(SLT** pphead, SLT* pos, SLT_data_type x);
//在指定位置之后插入
void SLT_insert_back(SLT* phead, SLT* pos, SLT_data_type x);
//删除指定位置的结点
void SLT_erase(SLT** pphead, SLT* pos);
//删除指定位置之后的结点
void SLT_erase_back(SLT* phead, SLT* pos);
//销毁链表
void SLT_destroy(SLT** pphead);
