#pragma once
#include"stdbool.h"
typedef struct account
{
	char useer[21];
	char password[21];
}account;
typedef struct SL User_table;

//保存账号
void Save_account(User_table* table);
//读取账号
void Read_account(User_table* table);
//创建用户
void Create_account(User_table* table);
//判断是否存在该用户
bool Is_exist(User_table* table,account person);
//登录
bool Register(User_table* table, account* person);
//修改用户名或密码
void Modification(User_table* table);
//注销账户
void Destroy_account(User_table* table);
//超级管理员
void Super_manager(User_table* table);

